const formulario = document.getElementById("formulario");
const tabla = document.getElementById("estudiantes");

formulario.addEventListener("submit", function (evento) {
  evento.preventDefault();

  const nombre = document.getElementById("nombre").value;
  const correo = document.getElementById("correo").value;
  const matricula = document.getElementById("matricula").value;

  const fila = document.createElement("tr");

  fila.innerHTML = `
    <td>${nombre}</td>
    <td>${correo}</td>
    <td>${matricula}</td>
  `;

  tabla.appendChild(fila);
  formulario.reset();
});